# Free AI Video Maker

A ready-to-upload Next.js video-maker starter designed to work without paid APIs.

## Included

- Text → storyboard/scenes
- Image → animated video (Ken Burns motion)
- Browser Speech Synthesis voice preview
- Background music upload
- Auto subtitles burned into the video
- YouTube 16:9, Shorts 9:16 and square 1:1
- Local browser rendering
- High bitrate WebM export
- Optional OpenAI-compatible script API
- Responsive mobile/desktop UI

## 1. Install

```bash
npm install
npm run dev
```

Open http://localhost:3000

## 2. GitHub

Create a GitHub repository and upload all files in this folder.

Typical commands:

```bash
git init
git add .
git commit -m "Initial AI video maker"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## 3. Vercel

Import the GitHub repository into Vercel.

Framework: Next.js  
Build command: `next build`

No environment variables are required for the free browser-only mode.

## Optional AI script generation

Copy `.env.example` to `.env.local` locally or add variables in Vercel:

```text
OPENAI_API_KEY=your_key
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_MODEL=gpt-4o-mini
```

The included API route is OpenAI-compatible, so it can also be pointed at another compatible provider.

## Important limitations

The completely free version does NOT claim to create true neural text-to-video or neural voice files. It creates videos locally using image animation, subtitles, browser voice preview and optional music.

For true generative video, AI image generation and downloadable neural voice, add provider adapters. Those services normally have usage limits or costs.

## Browser support

Chrome/Edge are recommended for the most consistent MediaRecorder export. The export is WebM. A production MP4 pipeline should use FFmpeg WASM or a server/GPU renderer.
