import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const { prompt, language = "English", scenes = 6 } = await req.json();

  if (!prompt?.trim()) {
    return NextResponse.json({ error: "Prompt is required." }, { status: 400 });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  const baseUrl = process.env.OPENAI_BASE_URL || "https://api.openai.com/v1";
  const model = process.env.OPENAI_MODEL || "gpt-4o-mini";

  // If no key exists, return a useful local fallback so the website remains free.
  if (!apiKey) {
    const sentences = [
      `Opening: ${prompt}`,
      `The story develops naturally with clear visual moments.`,
      `A new scene shows the main subject and its surroundings.`,
      `The atmosphere changes as the story reaches its key moment.`,
      `The final moment gives the audience a memorable conclusion.`,
      `End with a clean, positive closing shot.`
    ];
    return NextResponse.json({
      script: sentences.slice(0, Math.max(1, Math.min(12, Number(scenes) || 6))).join(" "),
      provider: "local-fallback"
    });
  }

  const response = await fetch(`${baseUrl.replace(/\/$/, "")}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model,
      temperature: 0.8,
      messages: [
        {
          role: "system",
          content:
            `You are a YouTube video script writer. Write a visual, scene-friendly script in ${language}. Keep it concise and divide it into ${scenes} short scenes. Return only the script.`
        },
        { role: "user", content: prompt }
      ]
    })
  });

  if (!response.ok) {
    return NextResponse.json({ error: "AI provider request failed." }, { status: 502 });
  }

  const data = await response.json();
  return NextResponse.json({
    script: data?.choices?.[0]?.message?.content || "",
    provider: "openai-compatible"
  });
}
