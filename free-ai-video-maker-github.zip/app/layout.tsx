import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Free AI Video Maker",
  description: "Text, images, voice and music video maker",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
