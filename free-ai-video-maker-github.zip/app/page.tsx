"use client";

import { useMemo, useRef, useState } from "react";
import { Download, ImagePlus, Music2, Play, Sparkles, Trash2, Upload, Video, Volume2 } from "lucide-react";

type Scene = {
  id: string;
  text: string;
  image?: string;
  duration: number;
};

type ExportResult = {
  blob: Blob;
  url: string;
};

const DEMO_SCRIPT =
  "A peaceful village wakes up at sunrise. Birds fly over green fields. A farmer walks toward the fields with hope. The day becomes bright and beautiful.";

function splitIntoScenes(text: string): Scene[] {
  const parts = text
    .split(/(?<=[.!?।])\s+/)
    .map((s) => s.trim())
    .filter(Boolean);

  const source = parts.length ? parts : [text.trim() || DEMO_SCRIPT];

  return source.slice(0, 12).map((text, i) => ({
    id: crypto.randomUUID(),
    text,
    duration: 4,
  }));
}

function wrapText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number) {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let line = "";

  for (const word of words) {
    const test = line ? `${line} ${word}` : word;
    if (ctx.measureText(test).width > maxWidth && line) {
      lines.push(line);
      line = word;
    } else {
      line = test;
    }
  }
  if (line) lines.push(line);
  return lines;
}

function drawScene(
  canvas: HTMLCanvasElement,
  scene: Scene,
  image: HTMLImageElement | null,
  progress: number,
  subtitle: boolean
) {
  const ctx = canvas.getContext("2d")!;
  const w = canvas.width;
  const h = canvas.height;

  ctx.fillStyle = "#0b1020";
  ctx.fillRect(0, 0, w, h);

  if (image) {
    const scale = 1.04 + progress * 0.12;
    const iw = image.naturalWidth;
    const ih = image.naturalHeight;
    const cover = Math.max(w / iw, h / ih) * scale;
    const dw = iw * cover;
    const dh = ih * cover;
    const x = (w - dw) / 2 - progress * 30;
    const y = (h - dh) / 2;
    ctx.drawImage(image, x, y, dw, dh);

    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, "rgba(0,0,0,.12)");
    g.addColorStop(0.65, "rgba(0,0,0,.15)");
    g.addColorStop(1, "rgba(0,0,0,.78)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  } else {
    const grad = ctx.createLinearGradient(0, 0, w, h);
    grad.addColorStop(0, "#172554");
    grad.addColorStop(1, "#111827");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    // Animated abstract background when no image is supplied.
    for (let i = 0; i < 18; i++) {
      const x = ((i * 173 + progress * 260) % (w + 200)) - 100;
      const y = (i * 97) % h;
      ctx.beginPath();
      ctx.arc(x, y, 25 + (i % 5) * 9, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255,255,255,${0.025 + (i % 3) * 0.01})`;
      ctx.fill();
    }
  }

  if (subtitle) {
    ctx.font = "700 42px Arial";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const lines = wrapText(ctx, scene.text, w - 150);
    const lineH = 52;
    const boxH = lines.length * lineH + 44;
    const boxY = h - boxH - 65;

    ctx.fillStyle = "rgba(0,0,0,.62)";
    ctx.roundRect(50, boxY, w - 100, boxH, 22);
    ctx.fill();

    ctx.fillStyle = "#fff";
    lines.forEach((line, i) => {
      ctx.fillText(line, w / 2, boxY + 24 + i * lineH + lineH / 2);
    });
  }
}

function speak(text: string, rate = 1) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text);
  utter.rate = rate;
  window.speechSynthesis.speak(utter);
}

export default function Home() {
  const [script, setScript] = useState("");
  const [scenes, setScenes] = useState<Scene[]>([]);
  const [format, setFormat] = useState<"landscape" | "portrait" | "square">("landscape");
  const [music, setMusic] = useState<File | null>(null);
  const [musicUrl, setMusicUrl] = useState("");
  const [musicVolume, setMusicVolume] = useState(0.18);
  const [voiceRate, setVoiceRate] = useState(1);
  const [subtitles, setSubtitles] = useState(true);
  const [rendering, setRendering] = useState(false);
  const [status, setStatus] = useState("Ready");
  const [result, setResult] = useState<ExportResult | null>(null);
  const imageInput = useRef<HTMLInputElement>(null);
  const musicInput = useRef<HTMLInputElement>(null);

  const dimensions = useMemo(() => {
    if (format === "portrait") return { w: 720, h: 1280 };
    if (format === "square") return { w: 1080, h: 1080 };
    return { w: 1280, h: 720 };
  }, [format]);

  function createVideoPlan() {
    const next = splitIntoScenes(script);
    setScenes(next);
    setResult(null);
    setStatus(`${next.length} scene(s) created`);
  }

  async function addImages(files: FileList | null) {
    if (!files) return;
    const urls = Array.from(files).slice(0, 12).map((f) => URL.createObjectURL(f));
    setScenes((old) => {
      const base = old.length ? old : splitIntoScenes(script);
      return base.map((s, i) => ({ ...s, image: urls[i % urls.length] }));
    });
    setStatus("Images added");
  }

  function removeScene(id: string) {
    setScenes((old) => old.filter((s) => s.id !== id));
  }

  function updateScene(id: string, patch: Partial<Scene>) {
    setScenes((old) => old.map((s) => (s.id === id ? { ...s, ...patch } : s)));
  }

  function addMusic(file: File | undefined) {
    if (!file) return;
    if (musicUrl) URL.revokeObjectURL(musicUrl);
    const url = URL.createObjectURL(file);
    setMusic(file);
    setMusicUrl(url);
  }

  async function exportVideo() {
    if (!scenes.length) {
      setStatus("Create scenes first");
      return;
    }

    setRendering(true);
    setResult(null);
    setStatus("Preparing high-quality preview renderer...");

    const canvas = document.createElement("canvas");
    canvas.width = dimensions.w;
    canvas.height = dimensions.h;

    // Canvas capture is supported in modern Chrome/Edge/Firefox/Safari.
    const stream = canvas.captureStream(30);
    const chunks: Blob[] = [];
    const mime =
      MediaRecorder.isTypeSupported("video/webm;codecs=vp9")
        ? "video/webm;codecs=vp9"
        : "video/webm";

    const recorder = new MediaRecorder(stream, {
      mimeType: mime,
      videoBitsPerSecond: 8_000_000,
    });

    recorder.ondataavailable = (e) => e.data.size && chunks.push(e.data);

    const images = await Promise.all(
      scenes.map(
        (s) =>
          new Promise<HTMLImageElement | null>((resolve) => {
            if (!s.image) return resolve(null);
            const img = new Image();
            img.onload = () => resolve(img);
            img.onerror = () => resolve(null);
            img.src = s.image;
          })
      )
    );

    recorder.start(200);

    const frameMs = 1000 / 30;
    for (let si = 0; si < scenes.length; si++) {
      const scene = scenes[si];
      const image = images[si];
      const frames = Math.max(30, Math.round(scene.duration * 30));

      setStatus(`Rendering scene ${si + 1}/${scenes.length}...`);

      // Start browser TTS for the scene. It plays during rendering but is
      // intentionally not captured; users can record/export voice separately
      // or use a TTS provider in the API adapter included below.
      if (si === 0) speak(scene.text, voiceRate);

      for (let f = 0; f < frames; f++) {
        drawScene(canvas, scene, image, f / frames, subtitles);
        await new Promise((r) => setTimeout(r, frameMs));
      }
    }

    window.speechSynthesis?.cancel();

    await new Promise<void>((resolve) => {
      recorder.onstop = () => resolve();
      recorder.stop();
    });

    const blob = new Blob(chunks, { type: mime });
    const url = URL.createObjectURL(blob);
    setResult({ blob, url });
    setRendering(false);
    setStatus("Video ready");
  }

  return (
    <main className="app">
      <header className="topbar">
        <div className="brand">
          <div className="brandIcon"><Video size={22} /></div>
          <div>
            <strong>Free AI Video Maker</strong>
            <span>Text • Image • Voice • Music</span>
          </div>
        </div>
        <div className="status">{rendering ? "Rendering…" : status}</div>
      </header>

      <section className="hero">
        <div>
          <div className="pill"><Sparkles size={15}/> Fast browser-based studio</div>
          <h1>Create YouTube videos from <em>text and images.</em></h1>
          <p>
            Build scenes, add your own images and music, generate subtitles,
            preview AI-style motion, and export a high-quality video directly
            from your browser.
          </p>
        </div>
      </section>

      <section className="workspace">
        <div className="panel left">
          <h2>1. Script</h2>
          <textarea
            value={script}
            onChange={(e) => setScript(e.target.value)}
            placeholder="Paste your story or YouTube script here..."
          />
          <div className="row">
            <button className="primary" onClick={createVideoPlan}>
              <Sparkles size={17}/> Create scenes
            </button>
            <button onClick={() => { setScript(DEMO_SCRIPT); setScenes(splitIntoScenes(DEMO_SCRIPT)); }}>
              Demo
            </button>
          </div>

          <h2>2. Media</h2>
          <div className="drop" onClick={() => imageInput.current?.click()}>
            <ImagePlus size={25}/>
            <strong>Add images</strong>
            <span>JPG, PNG, WebP • up to 12 scenes</span>
            <input
              ref={imageInput}
              hidden
              type="file"
              accept="image/*"
              multiple
              onChange={(e) => addImages(e.target.files)}
            />
          </div>

          <div className="drop" onClick={() => musicInput.current?.click()}>
            <Music2 size={25}/>
            <strong>{music ? music.name : "Add background music"}</strong>
            <span>MP3, WAV, M4A • optional</span>
            <input
              ref={musicInput}
              hidden
              type="file"
              accept="audio/*"
              onChange={(e) => addMusic(e.target.files?.[0])}
            />
          </div>

          {musicUrl && (
            <div className="musicBox">
              <audio controls src={musicUrl} />
              <label>
                Music volume: {Math.round(musicVolume * 100)}%
                <input
                  type="range"
                  min="0"
                  max="0.6"
                  step="0.01"
                  value={musicVolume}
                  onChange={(e) => setMusicVolume(Number(e.target.value))}
                />
              </label>
            </div>
          )}

          <h2>3. Settings</h2>
          <div className="settings">
            <label>
              Format
              <select value={format} onChange={(e) => setFormat(e.target.value as typeof format)}>
                <option value="landscape">YouTube 16:9</option>
                <option value="portrait">Shorts 9:16</option>
                <option value="square">Square 1:1</option>
              </select>
            </label>

            <label>
              Voice speed
              <input
                type="range"
                min="0.6"
                max="1.5"
                step="0.05"
                value={voiceRate}
                onChange={(e) => setVoiceRate(Number(e.target.value))}
              />
            </label>

            <label className="check">
              <input type="checkbox" checked={subtitles} onChange={(e) => setSubtitles(e.target.checked)} />
              Auto subtitles
            </label>
          </div>

          <button className="render" disabled={rendering} onClick={exportVideo}>
            <Play size={18}/> {rendering ? "Rendering..." : "Create video"}
          </button>

          {result && (
            <a className="download" href={result.url} download="ai-video-maker.webm">
              <Download size={18}/> Download video
            </a>
          )}

          <div className="note">
            <Volume2 size={15}/>
            Voice preview uses your browser&apos;s free Speech Synthesis engine.
            For downloadable AI voice-over, connect a TTS provider in the optional API adapter.
          </div>
        </div>

        <div className="panel right">
          <div className="panelTitle">
            <h2>Scenes</h2>
            <span>{scenes.length}/12</span>
          </div>

          {!scenes.length ? (
            <div className="empty">
              <Sparkles size={34}/>
              <h3>Your storyboard is empty</h3>
              <p>Enter a script and click “Create scenes”.</p>
            </div>
          ) : (
            <div className="scenes">
              {scenes.map((scene, i) => (
                <article className="scene" key={scene.id}>
                  <div className="sceneThumb">
                    {scene.image ? (
                      <img src={scene.image} alt="" />
                    ) : (
                      <div className="abstract"><Sparkles size={22}/></div>
                    )}
                    <span>{i + 1}</span>
                  </div>
                  <div className="sceneBody">
                    <textarea
                      value={scene.text}
                      onChange={(e) => updateScene(scene.id, { text: e.target.value })}
                    />
                    <div className="sceneControls">
                      <label>
                        Seconds
                        <input
                          type="number"
                          min="1"
                          max="20"
                          value={scene.duration}
                          onChange={(e) => updateScene(scene.id, { duration: Number(e.target.value) || 1 })}
                        />
                      </label>
                      <button className="danger" onClick={() => removeScene(scene.id)}>
                        <Trash2 size={16}/>
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}

          <div className="tips">
            <strong>Free mode</strong>
            <p>
              This version deliberately avoids paid APIs: motion is generated locally
              with the Ken Burns effect, subtitles are drawn into the video, and rendering
              happens in your browser. Add provider keys later for true generative
              text-to-video, AI images, and neural voices.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
